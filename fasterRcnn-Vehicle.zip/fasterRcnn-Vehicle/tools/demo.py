#!/usr/bin/env python

# --------------------------------------------------------
# Tensorflow Faster R-CNN
# Licensed under The MIT License [see LICENSE for details]
# Written by Xinlei Chen, based on code from Ross Girshick
# --------------------------------------------------------

"""
Demo script showing detections in sample images.

See README.md for installation instructions before running.
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import _init_paths
from model.config import cfg
from model.test import im_detect
from model.nms_wrapper import nms

from utils.timer import Timer
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import numpy as np
import os, cv2
import argparse

from nets.vgg16 import vgg16
from nets.resnet_v1 import resnetv1

import torch
import pdb

# CLASSES = ('__background__',
#            'aeroplane', 'bicycle', 'bird', 'boat',
#            'bottle', 'bus', 'car', 'cat', 'chair',
#            'cow', 'diningtable', 'dog', 'horse',
#            'motorbike', 'person', 'pottedplant',
#            'sheep', 'sofa', 'train', 'tvmonitor')

CLASSES = ('__background__',  # always index 0
                     'car', 'truck', 'van', 'tram')

NETS = {'vgg16': ('vgg16_faster_rcnn_iter_%d.pth',),'res101': ('res101_faster_rcnn_iter_%d.pth',)}
DATASETS= {'pascal_voc': ('voc_2007_trainval',),'pascal_voc_0712': ('voc_2007_trainval+voc_2012_trainval',)}

def vis_detections(im, class_name, dets, thresh=0.5):
    """Draw detected bounding boxes."""
    inds = np.where(dets[:, -1] >= thresh)[0]
    if len(inds) == 0:
        return

    # pdb.set_trace()
    # print(dets)
    # print('Final objects detected: {:s} {:d}'.format(class_name, len(inds)))  # show final object that detected. Lu Chang-Sheng

    im = im[:, :, (2, 1, 0)]
    plt.ion()
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.imshow(im, aspect='equal')
    for i in inds:
        bbox = dets[i, :4]
        score = dets[i, -1]

        ax.add_patch(
            plt.Rectangle((bbox[0], bbox[1]),
                          bbox[2] - bbox[0],
                          bbox[3] - bbox[1], fill=False,
                          edgecolor='yellow', linewidth=3.5) #red
            )
        ax.text(bbox[0], bbox[1] - 2,
                '{:s} {:.3f}'.format(class_name, score),
                bbox=dict(facecolor='green', alpha=0.5), #blue
                fontsize=14, color='white')

    ax.set_title(('{} detections with '
                  'p({} | box) >= {:.1f}').format(class_name, class_name,
                                                  thresh),
                  fontsize=14)
    plt.axis('off')
    plt.tight_layout()
    plt.draw()

#return the orientation maker coordinate of vehicle, Lu Chang-Sheng
def getOrientationPoint(bbox, orientation):
    xc = (bbox[0] + bbox[2])/2 #center x
    yc = (bbox[1] + bbox[3])/2 #center y
    xs = np.array([bbox[0], bbox[2]])
    ys = np.array([bbox[1], bbox[3]])
    pointlist1 = [
        np.array([bbox[0], bbox[1]]),
        np.array([bbox[2], bbox[1]]),
        np.array([bbox[2], bbox[3]]),
        np.array([bbox[0], bbox[3]])
    ]

    pointlist2 = []
    pointlist2.append((pointlist1[0]+pointlist1[3])/2)
    for i in range(3):
        pointlist2.append((pointlist1[i] + pointlist1[i+1])/2)
    pointlist = []
    for i in range(4):
        pointlist.append(pointlist2[i])
        pointlist.append(pointlist1[i])
    if (orientation == 0): #not defined
        return None
    else: #orientation = 1~8 which stands for 8 orientations
        if orientation == 8:
            return (pointlist[7] + pointlist[0] + np.array([xc, yc]))/3
        else:
            return (pointlist[orientation - 1] + pointlist[orientation] + np.array([xc, yc])) / 3



def demo(net, image_name):
    """Detect object classes in an image using pre-computed object proposals."""

    # Load the demo image
    #im_file = os.path.join(cfg.DATA_DIR, 'demo/Pascal VOC', image_name)
    im_file = os.path.join(cfg.DATA_DIR, 'demo/KITTI', image_name) #test samples directory
    im = cv2.imread(im_file)

    m = im[:, :, (2, 1, 0)]
    plt.ion()
    fig, ax = plt.subplots(figsize=(12, 12))
    ax.imshow(im, aspect='equal')

    # Detect all object classes and regress object bounds
    timer = Timer()
    timer.tic()
    scores, boxes, angle_scores = im_detect(net, im)
    timer.toc()
    print('Detection took {:.3f}s for {:d} object proposals.'.format(timer.total_time(), boxes.shape[0]))

    # Visualize detections for each class
    CONF_THRESH = 0.8
    NMS_THRESH = 0.3
    for cls_ind, cls in enumerate(CLASSES[1:]):
        cls_ind += 1 # because we skipped background
        cls_boxes = boxes[:, 4*cls_ind:4*(cls_ind + 1)]
        cls_scores = scores[:, cls_ind]

        dets = np.hstack((cls_boxes,
                          cls_scores[:, np.newaxis])).astype(np.float32)
        keep = nms(torch.from_numpy(dets), NMS_THRESH)
        dets = dets[keep.numpy(), :]

        #pdb.set_trace()
        angle_scores_refine = angle_scores[keep.numpy(), :] #Lu Chang-Sheng
        #vis_detections(im, cls, dets, thresh=CONF_THRESH)

        inds = np.where(dets[:, -1] >= CONF_THRESH)[0]
        if len(inds) == 0:
            continue

        for i in inds:
            bbox = dets[i, :4]
            score = dets[i, -1]
            angle_prob = np.max(angle_scores_refine[i, :])  #Lu Chang-Sheng
            orientation = np.where(angle_prob == angle_scores_refine[i, :])[0][0] #Lu Chang-Sheng
            orientation_maker_point = getOrientationPoint(bbox, orientation)      #Lu Chang-Sheng
            if cls == 'car':
                ax.add_patch(
                    plt.Rectangle((bbox[0], bbox[1]),
                                  bbox[2] - bbox[0],
                                  bbox[3] - bbox[1], fill=False,
                                  edgecolor='red', linewidth=3.5)  # red
                )
            else:
                ax.add_patch(
                    plt.Rectangle((bbox[0], bbox[1]),
                                  bbox[2] - bbox[0],
                                  bbox[3] - bbox[1], fill=False,
                                  edgecolor='yellow', linewidth=3.5)
                )

            ax.text(bbox[0], bbox[1] - 2,
                    '{:s} {:.3f} {:d}'.format(cls, score, orientation),
                    bbox=dict(facecolor='white', alpha=0.5),  # blue
                    fontsize=14, color='blue')
            if orientation_maker_point is not None:
                ax.plot(orientation_maker_point[0], orientation_maker_point[1], 'rv')  #Lu Chang-Sheng
        ax.set_title(('{:s}').format(image_name),
                     fontsize=14)
    plt.axis('off')
    plt.tight_layout()
    plt.draw()

def parse_args():
    """Parse input arguments."""
    parser = argparse.ArgumentParser(description='Tensorflow Faster R-CNN demo')
    parser.add_argument('--net', dest='demo_net', help='Network to use [vgg16 res101]',
                        choices=NETS.keys(), default='vgg16')
    parser.add_argument('--dataset', dest='dataset', help='Trained dataset [pascal_voc pascal_voc_0712]',
                        choices=DATASETS.keys(), default='pascal_voc')
    args = parser.parse_args()

    return args

if __name__ == '__main__':
    cfg.TEST.HAS_RPN = True  # Use RPN for proposals
    args = parse_args()

    # model path
    demonet = args.demo_net
    dataset = args.dataset
    saved_model = os.path.join('../output', demonet, DATASETS[dataset][0], 'default',
                              NETS[demonet][0] %(55000 if dataset == 'pascal_voc' else 110000))


    if not os.path.isfile(saved_model):
        raise IOError(('{:s} not found.\nDid you download the proper networks from '
                       'our server and place them properly?').format(saved_model))

    # load network
    if demonet == 'vgg16':
        net = vgg16()
    elif demonet == 'res101':
        net = resnetv1(num_layers=101)
    else:
        raise NotImplementedError
    net.create_architecture(5,         #class number, in original Pascal VOC that is 21, while 5 in KITTI, Lu Chang-Sheng
                          tag='default', anchor_scales=[8, 16, 32])

    net.load_state_dict(torch.load(saved_model))

    net.eval()
    net.cuda()

    print('Loaded network {:s}'.format(saved_model))

    #Pascal VOC
    # im_names = ['000456.jpg', '000542.jpg', '001150.jpg',
    #             '001763.jpg', '004545.jpg']

    #KITTI
    im_names = ['000008.png', '000013.png', '000343.png', '000349.png', '003355.png'
                 ,'005211.png', '005216.png', '005258.png']
                # ,'000090.png', '000091.png', '000092.png', '000093.png', '000094.png']

    for im_name in im_names:
        print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        print('Demo for data/demo/{}'.format(im_name))
        demo(net, im_name)

    plt.ioff()
    plt.show()
